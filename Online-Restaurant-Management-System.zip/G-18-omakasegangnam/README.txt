การใช้งาน
ลูกค้า
    กรณีเข้าสู่ระบบ
    อีเมลล์ fueng@gmail.com
    รหัสผ่าน 123456
พนักงานต้อนรับ
    อีเมลล์ reciep@gmail.com
    รหัสผ่าน reciep123
ผู้จัดการ
    อีเมลล์ gangnam@gmail.com
    รหัสผ่าน gangnammanager
เชฟ
    อีเมลล์ chef@gmail.com
    รหัสผ่าน chef123